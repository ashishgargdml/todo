import styled from "styled-components";
import { Button, Col, Select } from "antd";
import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { GiCancel } from "react-icons/gi";
import { FaCheck } from "react-icons/fa";

const AddTask = () => {
  let navigate = useNavigate();
  const [task, setTask] = useState({
    id: "",
    title: "",
    description: "",
    status: "",
  });

  const { id, title, description, status } = task;
  const onInputChange = (e) => {
    setTask({ ...task, [e.target.name]: e.target.value });
  };
  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:3003/tasks", task);
    navigate("/");
  };

  const data = [
    {
      value: "Completed",
      label: "Completed",
    },
    {
      value: 'In Progress',
      label: "In Progress',"
    },
    {
      value: 'pending',
      label: "pending"
    },
  ];
  return (
    <div>
      <COL offset={10}>
        <P>Id</P>
        <INPUT
          type="number"
          name="id"
          placeholder="Enter your id"
          value={id}
          onChange={onInputChange}
        />
        <P>Title</P>
        <INPUT
          type="text"
          name="title"
          placeholder="Enter Title of the Task"
          value={title}
          onChange={onInputChange}
        />
        <P>Description</P>
        <INPUT
          type="text"
          name="description"
          placeholder="Enter Description"
          value={description}
          onChange={onInputChange}
        />
        <P>Status</P>
        <Select onChange={onInputChange}  value={status} options={data}/>
      </COL>
      <Col style={{ marginTop: "10px" }} offset={11}>
        {id !== '' && status !== '' && description !== '' && title !== '' && status !== ''
        ?<Button onClick={onSubmit} type="primary">
          <FaCheck />
        </Button>:'fill all fields'}
        <B href="/">
          <GiCancel />
        </B>
      </Col>
    </div>
  );
};

const COL = styled(Col)`
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const P = styled.p``;

const INPUT = styled.input`
  width: 30%;
  height: 2em;
  border: 1px solid;
  border-radius: 4px;
`;

const STYLE = styled.select`
  width: 30%;
  height: 2em;
  ${"" /* margin-bottom:2px; */}
  border: 1px solid;
  border-radius: 4px;
`;

const B = styled(Button)`
  left: 10px;
`;

export default AddTask;
